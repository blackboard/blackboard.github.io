--Lists all custom created Data Source Keys
SELECT
batch_uid as "key",
description as "description"
FROM public.data_source
where
batch_uid not in ('INTERNAL','SYSTEM')
order by
batch_uid
;