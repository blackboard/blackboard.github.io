select
	"users"."batch_uid"       		as "external_person_key",
	"data_source"."batch_uid" 		as "data_source_key",
	"users"."firstname"       		as "firstname",
	"users"."lastname"        		as "lastname",
	"users"."user_id"        		as "user_id",
	"users"."available_ind"			as "available_ind",
	"users"."email"               	as "email",
	"institution_roles"."role_id" 	as "institution_role",
	"users"."system_role"         	as "system_role"  
from
	"public"."data_source" "data_source" 
		inner join "public"."users" "users" 
		on "data_source"."pk1" = "users"."data_src_pk1" 
			inner join "public"."institution_roles" "institution_roles" 
			on "institution_roles"."pk1" = "users"."institution_roles_pk1" 
where
	("data_source"."pk1" <> 1) 
order by
	"data_source"."batch_uid" asc,
	"users"."batch_uid" asc