select
	"institution_roles"."role_name",
	"institution_roles"."role_id",
	"institution_roles"."description" 
from
	"public"."institution_roles" "institution_roles" 
where
	("institution_roles"."removable_ind" = 'Y') 
order by
	"institution_roles"."role_name" asc
	;