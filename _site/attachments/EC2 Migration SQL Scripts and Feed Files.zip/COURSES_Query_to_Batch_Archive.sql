--Pulls list of courses into a Batch Archive feed file format
SELECT
	"course_main"."course_id" || ',/var/tmp/course_archives/' 
	AS "COURSE_ARCHIVE_PATH"
FROM
	"public"."course_main"
WHERE
    ("course_main"."data_src_pk1" <> 1)
    AND
    ("course_main"."service_level" = 'F')
ORDER BY
    "course_main"."course_id" 
;