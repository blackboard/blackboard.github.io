--Pulls list of courses into a Batch Restore feed file format
SELECT
	"course_main"."course_id" || 
	',/var/tmp/course_archives/ArchiveFile_' || 
	"course_main"."course_id" || '.zip' 
	AS "COURSE_RESTORE_PATH"
FROM
	"public"."course_main"
WHERE
    ("course_main"."data_src_pk1" <> 1)
    AND
    ("course_main"."service_level" = 'F')
ORDER BY
    "course_main"."course_id" 
;
