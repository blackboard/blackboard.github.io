Please install Blackboard custom PMD rules before importing Java rule set.

How to install Blackboard custom PMD rules
1. Copy bb-pmd-rules.jar and bb-rules-sonar.xml files to ${Sonar_Home}/extensions/rules/pmd
2. Make sure the files have read rights for Sonar
3. Restart Sonar server
4. Verify that Bb* rules exist from a Java profile's coding rules list

How to use Blackboard's Java rule set
1. Log in to Sonar as a user with Administrators role
2. Navigate to "Configuration" -> "Quality Profiles"
3. Click on "Restore profile" link located on the top right of the page
4. Select bb-sonar-profile-java.xml and click on "Restore profile" button
5. Specify the Sonar analysis configuration to use the restored profile
