package blackboard.devcon.spring.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import blackboard.data.course.Course;
import blackboard.data.user.User;
import blackboard.persist.KeyNotFoundException;
import blackboard.persist.PersistenceException;
import blackboard.persist.course.CourseDbLoader;
import blackboard.platform.context.Context;

/**
 * Controllers in Spring define web endpoints, much in the way Servlets do in the J2EE spec.
 * The advantage to this model is there is no strict inheritance hierarchy or interfaces that must
 * be implemented to define the endpoint.  Spring MVC is very flexible on mapping and executing the 
 * endpoint methods.
 * 
 * @author dashman
 */
@Controller
@RequestMapping( "/springContent" )
public class SpringContentController
{
  
  private CourseDbLoader _courseLoader;
  
  /**
   * We need the CourseDBLoader in this controller to load more data.
   * @param courseLoader
   */
  @Resource
  public void setCourseLoader( CourseDbLoader courseLoader )
  {
    _courseLoader = courseLoader;
  }
  

  /**
   * Defines a web endpoint (as defined by RequestMapping).  Any request to "/springContent"
   * will execute this method.
   * 
   * @param user The current user.
   * @param course The current course.
   * @param ctx A Blackboard request context.
   * @return The relative path to the view page.  This translates to WEB-INF/jsp/handle/content.jsp.
   * @throws KeyNotFoundException Thrown if the course load fails.
   * @throws PersistenceException Thrown if the course load fails.
   */
  @RequestMapping
  public ModelAndView springContent( User user, Course course, Context ctx ) throws KeyNotFoundException, PersistenceException
  {
    // ModelAndView objects allow you to put arbitrary objects in the request for use in the view.
    ModelAndView mv = new ModelAndView("handle/content");
    mv.addObject( "user", user );
    mv.addObject( "currentCourse", course );
    mv.addObject( "context", ctx );
    mv.addObject("otherCourses", _courseLoader.loadByUserId( user.getId() ));
    return mv;
  }

}
