package blackboard.devcon.spring.util;

import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.context.request.NativeWebRequest;

import blackboard.data.course.Course;
import blackboard.data.user.User;
import blackboard.platform.context.Context;
import blackboard.platform.context.ContextManagerFactory;

/**
 * This is Blackboard Spring plumbing code to let you use Blackboard API classes as method parameters
 * in controllers.  Spring will use this class to load the correct objects for the parameters.  This simplifies
 * the controller code to use Inversion of Control to pass in the necessary data.
 * 
 * @author dashman
 *
 */
@Component
public class BbArgumentResolver implements WebArgumentResolver
{

  @Override
  public Object resolveArgument( MethodParameter param, NativeWebRequest request ) throws Exception
  {
    if (User.class.isAssignableFrom( param.getParameterType() ) )
      return ContextManagerFactory.getInstance().getContext().getUser();
    else if (Context.class.isAssignableFrom( param.getParameterType() ) )
      return ContextManagerFactory.getInstance().getContext();
    else if (Course.class.isAssignableFrom( param.getParameterType() ) )
      return ContextManagerFactory.getInstance().getContext().getCourse();
    
    return UNRESOLVED;
  }

}
