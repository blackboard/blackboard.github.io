package blackboard.devcon.spring.util;

import java.lang.reflect.Method;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Required;

/**
 * This is Blackboard Spring plumbing code to let you use Blackboard API classes through Inversion of Control.
 * The Spring configuration file uses this FactoryBean to load the correct DBLoader or DBPersister for
 * your controllers to use.
 * 
 * @author dashman
 *
 */
public class BbPersistenceFactory implements FactoryBean
{
  
  private Class _typeClass;
  
  /**
   * Define the DBLoader or DBPersister interface you need.
   * @param t Loader or persister class.
   * @throws ClassNotFoundException
   */
  @Required
  public void setType(String t) throws ClassNotFoundException
  {
    _typeClass = Class.forName( t );
  }

  @Override
  public Object getObject() throws Exception
  {
    // Load the loader or persister using the <cls>.Default.getInstance() pattern.
    Class def = _typeClass.getClassLoader().loadClass( _typeClass.getName()+"$Default" );
    Method m = def.getMethod( "getInstance", new Class[0] );
    return m.invoke( def, new Object[0] );
  }

  @Override
  public Class getObjectType()
  {
    return _typeClass;
  }

  @Override
  public boolean isSingleton()
  {
    return true;
  }

}

  