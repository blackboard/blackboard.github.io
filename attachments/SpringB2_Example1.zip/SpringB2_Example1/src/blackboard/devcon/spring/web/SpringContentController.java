package blackboard.devcon.spring.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controllers in Spring define web endpoints, much in the way Servlets do in the J2EE spec.
 * The advantage to this model is there is no strict inheritance hierarchy or interfaces that must
 * be implemented to define the endpoint.  Spring MVC is very flexible on mapping and executing the 
 * endpoint methods.
 * 
 * @author dashman
 */
@Controller
@RequestMapping( "/springContent" )
public class SpringContentController
{
  
  /**
   * Defines a VERY simple web endpoint (as defined by RequestMapping).  Any request to "/springContent"
   * will execute this method.
   * 
   * @return The relative path to the view page.  This translates to WEB-INF/jsp/handle/content.jsp.
   */
  @RequestMapping
  public String createContent( )
  {
    return "handle/content";
  }

}
